package com.example.senai.api_conexao_android;

public interface IEnviadorTextoSimplesPHP {
    void enviarParaPHP(String texto);
}
