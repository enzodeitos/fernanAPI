package com.example.senai.api_conexao_android;

import java.util.HashMap;

public interface IEnviadorHashMapPHP {
    void enviarParaPHP(HashMap map);
}
